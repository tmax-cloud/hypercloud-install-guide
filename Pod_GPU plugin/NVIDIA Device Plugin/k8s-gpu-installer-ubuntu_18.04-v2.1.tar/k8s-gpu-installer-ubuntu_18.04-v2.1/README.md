# K8S GPU Installer (For Ubuntu)
__*This is not an installation guide for deploying GPU VMs!*__

The k8s-gpu-installer contains scripts for installing nvidia driver on gpu node and deploying nvidia device plugin daemonset for kubernetes.
- gpunode-install-nvidia-docker2 script allows users to create gpu accerlerated docker containers.
- masternode-add-device-plugin script allows users to expose the number of GPUs on each nodes of k8s cluser and run GPU enabled containers in k8s cluster.


## FOR GPU NODE
### Install nvidia driver
* Install the proper nvidia driver for your GPU device before execute the gpunode-install-nvidia-docker2 script
    * Disable nouveau to avoid conflict with driver
        ```bash
        vi /etc/modprobe.d/blacklist-nvidia-nouveau.conf
        # write the following to the file:
        blacklist nouveau
        options nouveau modeset=0
        ```
    * Reboot
    * Install the required package
        ```bash
        apt-get install -y build-essential linux-headers-generic gcc make dkms jq
        ```
    * Download and install the proper nvidia driver for your GPU device from https://www.nvidia.co.kr/Download/index.aspx
        ```bash
        chmod +x ./your-nvidia-file.run
        ./your-nvidia-file.run --dkms -s
        ```
* How to verify that nvidia driver is installed successfully
    ```bash
    nvidia-smi
    ```

### Install nvidia-docker2
* Install nvidia-docker2
    ```bash
    ./gpunode-install-nvidia-docker2.sh
    ```
    * If it prints 'Configuration file /etc/docker/daemon.json', press ENTER(or N)
        * ![Test of installing nvidia-docker2](test-of-installing-nvidia-docker.jpg)
* How to verify that driver and toolkit are installed successfully
    ```bash
    docker run nvidia/cuda:9.0-base nvidia-smi
    ```


## FOR MASTER NODE
### Assign label to GPU nodes
* Assign 'tmax/gpudriver=nvidia' label to GPU nodes
    ```bash
    kubectl label nodes {GPU node name} tmax/gpudriver=nvidia
    ```
### Add NVIDIA device plugin
* Deploy nvidia gpu device plugin daemonset
    ```bash
    ./masternode-add-device-plugin.sh
    ```
* How to verify that the daemonset is deployed successfully
    ```bash
    # to verify nvidia-device-plugin pods are running
    kubectl get pods -n kube-system | grep nvidia-device-plugin-daemonset
    
    # to check the number of gpu devices on each nodes
    kubectl get nodes "-o=custom-columns=NAME:.metadata.name,GPU:.status.allocatable.nvidia\.com/gpu"
    ```
