#!/bin/bash
# run on master node

# edit k8s DevicePlugins
LINE='Environment="KUBELET_EXTRA_ARGS=--feature-gates=DevicePlugins=true"'
FILE='/etc/systemd/system/kubelet.service.d/10-kubeadm.conf'
grep -q "$LINE" $FILE || sed -i "/ExecStart=$/i $LINE" $FILE

# apply to daemon
systemctl daemon-reload
systemctl restart kubelet

# enable gpu support (https://raw.githubusercontent.com/NVIDIA/k8s-device-plugin/1.0.0-beta4/nvidia-device-plugin.yml)
kubectl create -f ./nvidia-device-plugin-daemonset.yml
