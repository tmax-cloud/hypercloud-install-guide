#!/bin/bash

print_split () {
        SPLIT="============================================"
        echo "$SPLIT $1 $SPLIT"
}

install_package () {
        PKG_LIST=("$@")
        FAILED_LIST=()
        for PKG in ${PKG_LIST[@]}; do
                yum -y install $PKG
                if [ $? -ne 0 ]; then
                        FAILED_LIST+=($PKG)
                fi
        done
        if [ ! -z $FAILED_LIST ]; then
                echo "Failed to install packages : ${FAILED_LIST[*]}"
                exit 1
        fi
}

install_nvidia_docker2 () {
        # save docker setting before install nvidia-docker2
        DOCKER_DAEMON_JSON_PATH='/etc/docker/daemon.json'
        ORIG_CONTENT=`cat $DOCKER_DAEMON_JSON_PATH`

        # install nvidia-docker2
        install_package "nvidia-docker2"

        # set nvidia runtime for docker
        NEED_TO_ADD='{"default-runtime": "nvidia", "runtimes":{"nvidia":{"path":"nvidia-container-runtime", "runtimeArgs": []}}}'
        echo $ORIG_CONTENT | jq ". += $NEED_TO_ADD" > $DOCKER_DAEMON_JSON_PATH

        # apply settings
        systemctl restart docker
        EXIT_CODE=$?
        if [ $EXIT_CODE -ne 0 ]; then
                echo "Failed to restart docker daemon"
                exit $EXIT_CODE
        fi
}

# install packages
print_split "Install Packages"
KERNEL_RELEASE=`uname -r | sed "s/.\`uname -m\`//g"`
PKG_LIST=("jq")
install_package "${PKG_LIST[@]}"

# install nvidia-docker2
print_split "Install nvidia-docker2"
install_nvidia_docker2

print_split "Done"
